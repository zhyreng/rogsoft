#!/bin/sh


rm -rf /koolshare/ssid
rm -rf /init.d/S92ssid.sh
rm -rf /scripts/ssid_*.sh
rm -rf /webs/Module_ssid.asp

