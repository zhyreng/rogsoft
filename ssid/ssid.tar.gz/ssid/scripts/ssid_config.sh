#! /bin/sh

sh /koolshare/ssid/ssid.sh start
