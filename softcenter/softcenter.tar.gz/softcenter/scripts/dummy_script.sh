#!/bin/sh
export KSROOT=/jffs/koolshare
source $KSROOT/scripts/base.sh

http_response "$1"