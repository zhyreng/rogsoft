#!/bin/sh

# something need to start here
export KSROOT=/jffs/koolshare
source $KSROOT/scripts/base.sh
export PERP_BASE=$KSROOT/perp
mkdir -p /tmp/upload


